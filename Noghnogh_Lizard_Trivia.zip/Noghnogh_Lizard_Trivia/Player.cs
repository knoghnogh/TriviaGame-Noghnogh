﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Noghnogh_Lizard_Trivia
{
    public class Player
    {
        public int point;
        public static string Name;

        public void SubmitAnswer()
        {
            throw new System.NotImplementedException();
        }
    }
}