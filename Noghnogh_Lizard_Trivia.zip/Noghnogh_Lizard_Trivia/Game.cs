﻿using static System.Console;


namespace Noghnogh_Lizard_Trivia
{
    class Game
    {
        public string Setting;
        public string Name;
        public int Goal;

        public void Start()
        {
            Title = "hello";
            WriteLine("What is your name?");
            //
            Player.Name = ReadLine();
            //
            WriteLine("Hi" + Player.Name + ", welcome to Trivia!");

            //make two questions
            Question LegLess = new Question();
            //add values to the properties
            LegLess.QuestionText = "Some lizards are legless. (True or False)";
            LegLess.CorrectAnswer = "True";

            Question FrilledLizard = new Question();
            FrilledLizard.QuestionText = "Where do you find Frilled Neck-Lizard in the wild? (that start with an a)";
            FrilledLizard.CorrectAnswer = "Australia";

            string input;
            WriteLine(LegLess.QuestionText);
            input = ReadLine();
            WriteLine("Your answer: " + input + ", the correct answer: " + LegLess.CorrectAnswer);

            WriteLine(FrilledLizard.QuestionText);
            input = ReadLine();
            WriteLine("Your answer: " + input + ", the correct answer: " + FrilledLizard.CorrectAnswer);

            WriteLine("Thanks! We hope you had fun playing Trivia!");
            ReadKey();
        }
    }
}