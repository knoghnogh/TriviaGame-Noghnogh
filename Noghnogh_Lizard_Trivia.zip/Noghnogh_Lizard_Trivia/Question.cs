﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Noghnogh_Lizard_Trivia
{
    public class Question
    {
        public string QuestionText;
        public string CorrectAnswer;

        public void CheckAnswer()
        {
            throw new System.NotImplementedException();
        }

        public void ShowQuestion()
        {
            throw new System.NotImplementedException();
        }
    }
}